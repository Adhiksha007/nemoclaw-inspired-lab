# NemoClaw-inspired Agent Lab (simulation)

A beginner-friendly Streamlit app designed for GitHub Codespaces. It demonstrates policy concepts using ordinary Python checks and optionally calls OpenRouter's free-model router.

> **Security notice:** This is not NVIDIA NemoClaw and does not use OpenShell. Policy checks are simulated in the app. They are not a security boundary. Do not run untrusted code or use this to protect sensitive data.

## Run in GitHub Codespaces
1. Create a GitHub repository and upload these files.
2. Select **Code → Codespaces → Create codespace on main**.
3. In the Codespaces terminal run:

   ```bash
   pip install -r requirements.txt
   streamlit run app.py --server.address 0.0.0.0 --server.port 8501
   ```
4. Open forwarded port `8501` in the browser.

## Optional hosted AI
The app works without an API key using a labelled fallback. For hosted inference:
1. Create a key at https://openrouter.ai/ and check current free model availability and limits.
2. In the GitHub repository, go to **Settings → Secrets and variables → Codespaces → New repository secret**.
3. Name it `OPENROUTER_API_KEY` and set the key as the secret value.
4. Restart your Codespace so the secret is available.
5. Enable **Allow outbound AI API request** in the sidebar.

Never commit API keys or paste them into source code. Free availability and limits can change. Avoid sending private data to hosted models.

## Try these experiments
- Disable file listing, then try listing.
- Create `hello.txt`, disable read access, and try reading it.
- Try `../README.md` as a filename; the app should reject it.
- Keep network disabled and try an AI request; then enable it if you configured a key.
- Inspect the audit log.

## Simulated vs real
| Feature | Status |
|---|---|
| Chat UI | Real |
| Hosted AI request | Real only if key configured and network toggle enabled |
| Workspace file operations | Real, guarded by app-level checks |
| Allow/deny policy toggles | Simulation only |
| Shell execution | Not implemented |
| OpenShell isolation / kernel-enforced policy | Not present |
| NemoClaw CLI, gateway, lifecycle, blueprint | Not present |

## Next step
After learning these concepts, follow the official setup and platform prerequisites:
- https://docs.nvidia.com/nemoclaw/latest/
- https://docs.nvidia.com/openshell/home
